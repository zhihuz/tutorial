# encoding=utf8

from pymongo import MongoClient
from bson import ObjectId
from flask import Flask, request, json, abort, jsonify
from flask import Blueprint
import ConfigParser
import json
import base64

mongo_blueprint = Blueprint("mongo_blueprint", __name__)

#reading database information from blink.ini
cp = ConfigParser.SafeConfigParser()
cp.read('/home/solosseason/blink/blink.ini')
dbhost = cp.get('db', 'DBHOST')
dbuser = cp.get('db', 'DBUSER')
dbpasswd = cp.get('db', 'DBPWD')
dbport = cp.getint('db', 'DBPORT')
web_host = cp.get('web_server', 'WEB_HOST')
web_host_prefix = cp.get('web_server', 'WEB_HOST_PREFIX')
web_port =cp.getint('web_server', 'WEB_PORT')

# 连接数据库
client = MongoClient("mongodb://{dbuser}:{dbpasswd}@{dbhost}".format(dbuser=dbuser,
                                                                     dbpasswd=dbpasswd,
                                                                     dbhost=dbhost),dbport)
# 测试用例
# urllib2.Request(url='localhost/insert',
#                 data=json.dumps([{'id':1,'label':'a'},{'id':2,'label':'b'}]),
#                 headers={'content-type': 'application/json',"Accept": "application/json"})
#post参数：格式为列表或字典
@mongo_blueprint.route("/insert", methods = ['POST'])
def insert():
    '''
    @summary:（批量）插入数据
    @return: 插入结果，插入状态（errcode：0表成功，1表失败），报错信息（errinfo）
    '''
    try:
        #校验数据的md5值
        #m5 = request.json['accesstoken']
        db = client[request.json['dbname']]
        collection = db[request.json['collection']]
        fields = eval(base64.b64decode(request.json['fields']))
        # 验证fields是否合法
        assert len(fields)
        assert isinstance(fields,list) or isinstance(fields,dict)
        collection.insert(fields)
    except Exception, errinfo:
        print errinfo
        return jsonify({'errcode':1,'errinfo':errinfo})
    return jsonify({'errcode':0})

# 测试用例
# urllib2.Request(url='localhost/query',
#                 data=json.dumps({'id':1,'label':'a'}),
#                 headers={'content-type': 'application/json',"Accept": "application/json"})
#post参数：格式为字典
@mongo_blueprint.route("/query", methods = ['POST'])
def query():
    '''
    @summary:查询数据，查询条件不能为_id
    @return: 查询结果，查询状态（errcode：0表成功，1表失败），报错信息（errinfo）
    '''
    try:
        #校验数据的md5值
        #m5 = request.json['accesstoken']
        db = client[request.json['dbname']]
        collection = db[request.json['collection']]
        fields = eval(base64.b64decode(request.json['fields']))
        # 验证fields是否合法
        assert len(fields)
        assert isinstance(fields,dict)
        result_list = []
        for obj in collection.find(fields).sort(request.json['sort']):
            obj['_id'] = str(obj['_id'])
            result_list.append(obj)
    except Exception, errinfo:
        print errinfo
        return jsonify({'errcode':1,'errinfo':errinfo})
    return jsonify({'errcode':0,'query results':result_list})

# 测试用例
# urllib2.Request(url='localhost/query_id',
#                 data=json.dumps('56e6552e703b4e16e5769772'),
#                 headers={'content-type': 'application/json',"Accept": "application/json"})
#post参数：格式为字符串
@mongo_blueprint.route("/query_id", methods = ['POST'])
def query_id():
    '''
    @summary:根据_id查询
    @return: 查询结果，查询状态（errcode：0表成功，1表失败），报错信息（errinfo）
    '''
    try:
        db = client[request.json['dbname']]
        collection = db[request.json['collection']]
        id = base64.b64decode(request.json['fields'])
        # 验证id是否合法,_id长度为24
        assert len(id) ==24
        assert isinstance(id,str)
        obj = collection.find_one({'_id':ObjectId(id)})
        if not obj:
            return jsonify({'errcode':0,'query result':'NOT FOUND'})
        obj['_id'] = str(obj['_id'])
    except Exception, errinfo:
        print errinfo
        return jsonify({'errcode':1,'errinfo':errinfo})
    return jsonify({'errcode':0,'query result':obj})
