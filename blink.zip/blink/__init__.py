# coding=utf-8

import sys
sys.path.append('/home/solosseason')

from flask import Flask
from flask.ext.bootstrap import Bootstrap
from flask.ext.compress import Compress

# app
app = Flask(__name__)
Bootstrap(app)
Compress(app)

# data

# blueprint
#from blink.access.test import test_blueprint
#app.register_blueprint(test_blueprint)

from blink.access.mongo import mongo_blueprint
app.register_blueprint(mongo_blueprint)



